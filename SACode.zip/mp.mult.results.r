mp.mult.results <- function( mp.file.list, out.csv ) {
# Call mp.results for a list of files and export results as a csv file
#
# Author: Matthew Aiello-Lammens
# Created: 23 January 2011
#
# Args:
#	mp.file.list: a text file of the list of *.mp files for which results should be extracted
# 
# Returns:
#
#
###################################################################################################

mp.list <- readLines( mp.file.list )
mp.file.cnt <- length( mp.list )

mp.mult.res <- vector()
for ( mp in 1:mp.file.cnt ) {
	mp.res <- mp.results( mp.list[mp] )
	mp.mult.res <- rbind( mp.mult.res, mp.res )
}

###browser()
write.csv( mp.mult.res, out.csv )



}
