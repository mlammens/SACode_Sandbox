mp.results <- function( mpFile ) {
# Calculate various endpoints from the results of an MP simulation as carried out in RAMAS
# Use for Metapop version 5 and 5.1 file formats
# Based on ResOut.exe program written by R. Akcakaya
#
# Author: Matthew Aiello-Lammens
# Created: 9 January 2011
# Update: 20 January 2011
#
# Args:
#	mpFile: the full path name to the *.mp file to be examined
#
# Returns:
#	
#
###################################################################################################
# Check that *.mp file exists
if ( !file.exists( mpFile ) ){
	stop( paste( 'Did not find *.mp file:', mpFile) )
}

# Read *.mp file using mp.read.results.r.  If the file does not contain results
# it will be reported in the read script.
mp <- mp.read.results( mpFile )

# Get the *.mp parameter inputs
mp.in <- mp$mp.file[1:52]
# Get the *.mp results
mp.res <- mp$mp.file$results

# Created Results Summary (res.summ) list and initiate with length = 0
res.summ <- vector("list", length=0)

# Determine the initial meta-population size
# Only use the populations that are 'included in sum' when calculating inital metapop abundance
pop.initab <- mp.in$PopData_df$InitAbund
pop.includeinsum <- mp.in$PopData_df$IncludeInSum
metapop.initab <- sum( pop.initab * pop.includeinsum )
# Calculate 50% decline threshold
Thr.50 <- metapop.initab / 2

##### BEGIN REPORT OF INPUT VALUES (Indpendent Variables) #####
# ----------------------------------------------------------------------------------------------- #
# Call GenTime.exe to determine various calculations of generation time and eigen values
# WARNING: This only works on a Windows system write now
#!!!! Uncomment for Windows version !!!!
#gen.call <- paste( sens.base.dir,'GenTime ', '"', mpFile , '"',sep="" )
#print( paste('GenTime.exe called as: ', gen.call) ) ### DEBUG LINE
#gen <- system( gen.call, intern = TRUE )
#gen <- strsplit( gen, " ")
#gen <- unlist( lapply( gen, as.numeric ) )
# 	cols <- c("Abar","Mu1","Tgen","domEigenvalue","errorcode")

# Development Notes: figured out a way to run GenTime if Wine is installed
# wine <- '/Applications/Wine.app/Contents/Resources/bin/wine' # Works for my Mac
# gen.call <- paste( wine, 'GenTime.exe ', '"', mp.file , '"' )
# foo <- system( gen.call, intern=TRUE, ignore.stderr = TRUE )

##### BEGIN ENDPOINT CALCULATIONS (Dependent Variables) #####
# ----------------------------------------------------------------------------------------------- #
# Extinction Risk: Risk of total extinction by the final time step 
#
# Get the number of replications that resulted in 'extinction'
ext.rep <- length( which( mp.res$Replications$Ter == 0 ) )
# Exinction risk = (# reps resulting in extinction) / (total # of reps)
res.summ$ext.risk <- ext.rep / mp.res$SimRep # SimRep is the number of replicaitons in this simulation
# ----------------------------------------------------------------------------------------------- #
# Threshold: The quasi-extinction threshold. Value set in Stochasticity section of MP Module.
# Used to calculate time to quasi-extinction.
res.summ$threshold <- mp.in$ExtinctThr
# ----------------------------------------------------------------------------------------------- #
# Prob(maxt): Risk of falling below the Threshold at least once by the final time step
# Calculated using information regarding the time of first crossing of the extinction threshold
res.summ$prob.thresh.maxt <- sum( mp.res$TimeCross$QuasiExtinct ) / mp.res$SimRep
# ----------------------------------------------------------------------------------------------- #
# MedTime: Median time to fall below the quasi-extinction threshold
#
# First calculate cumulative sum of TimeCross$QuasiExtinct / SimRep (i.e. the prob of first 
# crossing the threshold at that time step)
prob.cross <- cumsum( mp.res$TimeCross$QuasiExtinct / mp.res$SimRep )
if ( any( prob.cross >= 0.5 ) ) { # Check if any values are greater than 0.5
	# Get the minimum time-step for which the prob.cross is greater than or equal to 0.5. In most cases
	# this will be an overestimate of the median time to quasi-extinction
	med.time.temp <- min( which(prob.cross >= 0.5) )
	# Approximation for med.time if med.time.temp does not occur at exactly 0.5
	if ( prob.cross[med.time.temp] != 0.5 ) {
		med.time <- (0.5-prob.cross[med.time.temp-1])/(prob.cross[med.time.temp]-prob.cross[med.time.temp-1]) + (med.time.temp-1)
	} else {
		med.time <- med.time.temp
	}
	# Correct for the 'stepsize'
	med.time <- med.time * mp.in$stepsize
} else {
	# If the median time to cross does not occur before the end of the simulation duration, 
	# then set to the maximum simulation duration + 1 (as done in RAMAS ResultsOut)
	res.summ$med.time.cross <- mp.in$MaxDur + 1
}
# ----------------------------------------------------------------------------------------------- #
# Prob(50): Risk of falling below a population size of 50 individuals at least once by the final
# time step
res.summ$prob.50 <- length( which( mp.res$Replications$Min <= 50 ) ) / mp.res$SimRep
# ----------------------------------------------------------------------------------------------- #
# Prob(250): Risk of falling below a population size of 250 individuals at least once by the final
# time step
res.summ$prob.250 <- length( which( mp.res$Replications$Min <= 250 ) ) / mp.res$SimRep
# ----------------------------------------------------------------------------------------------- #
# Prob(1000): Risk of falling below a population size of 1000 individuals at least once by the final
# time step
res.summ$prob.1000 <- length( which( mp.res$Replications$Min <= 1000 ) ) / mp.res$SimRep
# ----------------------------------------------------------------------------------------------- #
# Prob(50%): Risk of falling below a population size of 50% the intial metapop size at least once 
# by the final time step
res.summ$prob.Thr.50 <- length( which( mp.res$Replications$Min <= Thr.50 ) ) / mp.res$SimRep
# ----------------------------------------------------------------------------------------------- #
# ExpMinN: Expected minimum total abundance (also known as EMA)
res.summ$exp.min.n <- mean( mp.res$Replications$Min )
# ----------------------------------------------------------------------------------------------- #
# SdErr.ExpMinN: Standard error of EMA
res.summ$sderr.ema <- sqrt( var( mp.res$Replications$Min ) ) / sqrt( mp.res$SimRep )
# ----------------------------------------------------------------------------------------------- #
# N(maxt): Mean metapopulation abundance at the final time step maxt
# This value is the same as mp.res$PopAll$Mean( maxt )
res.summ$n.mean <- mean( mp.res$Replications$Ter )
# ----------------------------------------------------------------------------------------------- #
# SD of N: Standard deviation of metapopulation occupancy at the final time step maxt
# This value is the same as mp.res$PopAll$StDev( maxt )
res.summ$n.stdev <- sqrt( var(mp.res$Replications$Ter) )
# ----------------------------------------------------------------------------------------------- #
# % Metapop Ab Change: Percent change in total metapopulation size compared to initial 
# metapopulation size
res.summ$metapop.chng <- ( res.summ$n.mean - metapop.initab ) / metapop.initab
# ----------------------------------------------------------------------------------------------- #
# Occ(maxt): Mean metapopulation occupance at the final time step maxt
res.summ$occ.maxt <- mp.res$Occupancy$Mean[ mp.in$MaxDur ]
# ----------------------------------------------------------------------------------------------- #
# SD of Occ: Standard deviation of metapopulation occupancy at the final time step maxt
res.summ$occ.stdev.maxt <- mp.res$Occupancy$StDev[ mp.in$MaxDur ]
# ----------------------------------------------------------------------------------------------- #
# Quantiles of Terminal Population Trajectory.  5%, 25%, 50%, 75%, and 95% quantiles
quants <- quantile( mp.res$Replications$Ter, prob = c(0.05, 0.25, 0.50, 0.75, 0.95) )
res.summ$quant.05 <- quants[1]
res.summ$quant.25 <- quants[2]
res.summ$quant.50 <- quants[3]
res.summ$quant.75 <- quants[4]
res.summ$quant.95 <- quants[5]
# ----------------------------------------------------------------------------------------------- #
# Harvest Results: Average total harvest, St.Dev. of total harvest, Minimum of total harvest
# Maximum of total harvest
res.summ$harv.avg <- mp.res$HarvestTot$Mean
res.summ$harv.stdev <- mp.res$HarvestTot$StDev
res.summ$harv.min <- mp.res$HarvestTot$Min
res.summ$harv.max <- mp.res$HarvestTot$Max

###browser()
res.summ.df <- as.data.frame(res.summ)
row.names(res.summ.df) <- mpFile
return(res.summ.df)
}
